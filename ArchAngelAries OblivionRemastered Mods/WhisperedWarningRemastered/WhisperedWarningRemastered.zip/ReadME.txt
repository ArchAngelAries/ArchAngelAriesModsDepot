Port of the original "Whispered Warning" mod by Geniel, with fixes by OldWorthington. Now fully reworked and functional in Oblivion Remastered.

DESCRIPTION

This is a tweak of one of the original Dark Brotherhood quests—The Purification. It gives the player the option to warn the Dark Brotherhood family members in the Cheydinhal Sanctuary of the Purification Assassination Order, who then fake their own deaths and go into hiding. It’s a bit of a cheat, sure—but it was made with love for the characters and offers a reasonably believable way to spare them. When you reach the Listener rank in the Dark Brotherhood, they return as if nothing ever happened.

Originally released by Geniel and later fixed up by OldWorthington, this version has been fully ported and reworked for compatibility with Oblivion Remastered.


CHANGES IN THIS VERSION (REMASTERED PORT)

Ported and fully functional in Oblivion Remastered utilizing UE4SS and TesSyncMapInjector
Verified to work fully from Quest Start to Finish in Oblivion Remastered
Based on OldWorthington’s cleaned-up .esp, with further tweaks for Remastered-specific changes


Compatabilty

⚠️ I have not tested this with other Dark Brotherhood mods. It should be compatible as long as they don’t alter The Purification quest or the original DB storyline.

⚠️ May conflict with other DB Overhauls or mods that edit the Cheydinhal Sanctuary. If so, please reach out in the comments and I'll see if I can make a patch.



INSTALLATION

Install UE4SS for OblivionRemastered

Install UE4SS TesSyncMapInjector

Extract Archive to your: 
Steam\steamapps\common\Oblivion Remastered
folder

Add
Whispered Warning Remastered.esp
to your
Plugins.txt

Note: I am using the Steam version and don't know anything about installing on Game Pass, so whatever install method is necessary for installing ESP mods on Game Pass, follow that process.

SPOILERS

During The Purification, once you've received your orders from Lucien Lachance and enter the Sanctuary, a new dialogue option will appear:"[whisper a warning.]"
Saying this to any of the Sanctuary dwellers will trigger a short sequence. After a few seconds, you’ll receive a note instructing you to leave the Sanctuary for two days. When you return, those you warned will be gone, replaced by look-alike corpses.
You can still kill some or all of them if you wish—the system accounts for that. Either way, Lachance believes you've carried out the mission, and the quest proceeds as normal. If spared, the NPCs return later after you’ve become Listener.

Note: It is advised on the original mod page comment section to re-enter the sanctuary via the Abandoned House Basement Entrance and not the Well for the first time after the two day wait. Afterwards you can still come & go as normal. But I would recommend not returning until you have achieved the rank of Listener. It shouldn't cause issues if you do, but to ensure a smooth Cell reset it's likely the safest choice.


Known Issues:

Gogron gro-Bolmog's lookalike corpse does not wear the Daedric Armor

Entering the Sanctuary via the Well instead of the Basement Entrance after the two day wait may make result in the lookalike corpse not spawning


CREDITS

Geniel﻿ – Original author

OldWorthington﻿ – Fixed version and cleanup

xEdit team – For the xEdit modding tools

UE4SS-RE & KZekai – For UE4SS for OblivionRemastered﻿

GodschildGaming – For UE4SS TesSyncMapInjector﻿

Darkaxt – For UE4SS TesSyncMapInjector - Smart Mapper﻿

The mod.kitchen discord for pointing me in the right direction and being kind & helpful


Disclaimer:

I have reached out to both original authors out of respect to seek permission. However, Geniel has been inactive since 2008, and OldWorthington inactive since 2021. Per Nexus guidelines, .esp files are not considered protected assets and are technically free to patch, fix, or port, so long as credit is given—which I have done here in full transparency. That said, even though the original mod authors have been inactive for years, if either reach out to me and request me to take this port down I will gladly do so.